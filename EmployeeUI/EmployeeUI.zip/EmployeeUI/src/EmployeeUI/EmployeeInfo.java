package EmployeeUI;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Acer
 */
public class EmployeeInfo {   	
	int employeeNumber;
	String firstName;
	String lastName;
        String middleName;
        String gender;
	double deductionRate; 
        double netIncome;   
}
